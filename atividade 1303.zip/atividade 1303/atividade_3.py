import numpy as np

tempos = [20, 25, 30, 35, 40, 45, 90]

# O numpy calcula percentis usando interpolação linear por padrão
q1 = np.percentile(tempos, 25)
q2 = np.percentile(tempos, 50)
q3 = np.percentile(tempos, 75)

iqr = q3 - q1
limite_inferior = q1 - (1.5 * iqr)
limite_superior = q3 + (1.5 * iqr)

print("--- RESULTADOS COM NUMPY (EXEMPLO 03) ---")
print(f"Q1 = {q1}")
print(f"Q2 = {q2}")
print(f"Q3 = {q3}")
print(f"IQR = {iqr}")
print(f"Limites: [{limite_inferior}, {limite_superior}]")

# Detecção de outliers
outliers = [x for x in tempos if x < limite_inferior or x > limite_superior]
print(f"Outliers: {outliers}")

print("\n--- COMPARAÇÃO COM EXEMPLO 01 ---")
print("No Exemplo 01 (manual/statistics): Q1=25, Q3=45, IQR=20")
print(f"No Exemplo 03 (numpy):             Q1={q1}, Q3={q3}, IQR={iqr}")
print("CONCLUSÃO: O numpy interpola os valores. Como 25% cai entre índices, ele calcula uma média ponderada.")
print("Isso altera ligeiramente os limites de outliers.")