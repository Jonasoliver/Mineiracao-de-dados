import statistics

# Lista de dados
tempos = [20, 25, 30, 35, 40, 45, 90]
tempos.sort() # Importante: os dados devem estar ordenados

# --- Passo 1: Calcular Q2 (Mediana) ---
q2 = statistics.median(tempos)
n = len(tempos)

# --- Passo 2: Dividir a lista de forma genérica ---
# Se o número de elementos for ímpar, a mediana não entra nas metades.
# Se for par, divide ao meio exato.
if n % 2 == 0:
    metade_inferior = tempos[:n//2]
    metade_superior = tempos[n//2:]
else:
    # Exclui o elemento central (mediana) das sub-listas
    metade_inferior = tempos[:n//2]
    metade_superior = tempos[n//2+1:]

# --- Passo 3: Calcular Q1 e Q3 (Medianas das metades) ---
q1 = statistics.median(metade_inferior)
q3 = statistics.median(metade_superior)

# --- Passo 4: Calcular IQR e Limites ---
iqr = q3 - q1
limite_inferior = q1 - (1.5 * iqr)
limite_superior = q3 + (1.5 * iqr)

print(f"Lista Ordenada: {tempos}")
print(f"Metade Inferior: {metade_inferior}")
print(f"Metade Superior: {metade_superior}")
print("-" * 20)
print(f"Q1 (25%): {q1}")
print(f"Q2 (50%): {q2}")
print(f"Q3 (75%): {q3}")
print(f"IQR: {iqr}")
print(f"Limites: [{limite_inferior}, {limite_superior}]")
print("-" * 20)

# --- Passo 5: Detectar Outliers (Desafio 1) ---
outliers = []
for valor in tempos:
    if valor < limite_inferior or valor > limite_superior:
        outliers.append(valor)

if len(outliers) > 0:
    print(f"Outliers encontrados: {outliers}")
else:
    print("Nenhum outlier encontrado.")