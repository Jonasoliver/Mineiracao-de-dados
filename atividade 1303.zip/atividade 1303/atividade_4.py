import numpy as np

tempos = [20, 25, 30, 35, 40, 45, 90]

# Calcula os três de uma vez passando uma lista de percentis
q1, q2, q3 = np.percentile(tempos, [25, 50, 75])

iqr = q3 - q1
limite_inferior = q1 - (1.5 * iqr)
limite_superior = q3 + (1.5 * iqr)

print("--- RESULTADOS COM NUMPY ARRAY (EXEMPLO 04) ---")
print(f"Q1 = {q1}")
print(f"Q2 = {q2}")
print(f"Q3 = {q3}")
print(f"IQR = {iqr}")
print(f"Limites para Outliers: < {limite_inferior} ou > {limite_superior}")

# Verificação visual
for t in tempos:
    status = "Normal"
    if t < limite_inferior or t > limite_superior:
        status = "OUTLIER"
    print(f"Valor: {t} -> {status}")