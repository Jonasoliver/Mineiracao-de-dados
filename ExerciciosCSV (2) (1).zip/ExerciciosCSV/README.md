# Exercícios CSV - Detecção de Anomalias com Python

Esses exercícios foram feitos pra praticar análise de dados com Python, focando em detecção de outliers usando IQR, manipulação de DataFrames com pandas e limpeza de dados reais de sensores.

---

## O que você vai precisar

- Python 3.12 ou mais recente (evite versões alpha tipo 3.15a, podem dar problema com pacotes)
- pip instalado junto com o Python

Só isso. O resto a gente instala com um comando.

---

## Como rodar

### 1. Clone o repositório

```bash
git clone <url-do-repositorio>
cd ExerciciosCSV
```

### 2. Instale as dependências

```bash
python -m pip install numpy pandas
```

### 3. Rode os exercícios

Cada arquivo é independente, dá pra rodar na ordem que quiser:

```bash
python exercicios_1_2.py
python exercicios_3_a_6.py
python exercicios_7_a_10.py
python exercicios_11_12.py
```

> **Atenção:** o `exercicios_11_12.py` depende do arquivo `dados_sensores.csv` que já está na pasta. Sem ele, o script não vai funcionar. Certifique que o CSV está no mesmo diretório antes de rodar.

---

## O que cada arquivo faz

| Arquivo | Conteúdo |
|---|---|
| `exercicios_1_2.py` | Cálculo de quartis (Q1, Q2, Q3) e IQR com numpy |
| `exercicios_3_a_6.py` | Fatiamento de listas, filtro manual de anomalias e função genérica de detecção |
| `exercicios_7_a_10.py` | DataFrames com pandas, máscaras booleanas, `np.where` e agrupamento por sensor |
| `exercicios_11_12.py` | Leitura de CSV real, tratamento de valores nulos, remoção de outliers e exportação |

Ao rodar o `exercicios_11_12.py`, um arquivo `dados_validados.csv` vai ser gerado automaticamente na mesma pasta com os dados já limpos.

---

## Estrutura do projeto

```
ExerciciosCSV/
├── dados_sensores.csv       # dados brutos de sensores (com nulos e outliers propositais)
├── exercicios_1_2.py
├── exercicios_3_a_6.py
├── exercicios_7_a_10.py
└── exercicios_11_12.py
```
