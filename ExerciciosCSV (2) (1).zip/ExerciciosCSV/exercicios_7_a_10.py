import pandas as pd
import numpy as np

# --- Exercício 7: DataFrame e quantile() ---
dados = {
    'ID_Maquina': [1, 2, 3, 4, 5],
    'Uso_Memoria_MB': [2048, 2100, 2050, 8192, 2080]
}
df = pd.DataFrame(dados)

q1 = df['Uso_Memoria_MB'].quantile(0.25)
q3 = df['Uso_Memoria_MB'].quantile(0.75)
iqr = q3 - q1

print(f"--- Exercício 7 ---")
print(f"Q1: {q1} | Q3: {q3} | IQR: {iqr}")

# --- Exercício 8: Máscara Booleana (Filtro) ---
lim_inf = q1 - (1.5 * iqr)
lim_sup = q3 + (1.5 * iqr)

# Criando a máscara (True para linhas normais, False para outliers)
# "hardware operou dentro da normalidade"
mascara_normalidade = (df['Uso_Memoria_MB'] >= lim_inf) & (df['Uso_Memoria_MB'] <= lim_sup)
df_limpo = df[mascara_normalidade]

print(f"\n--- Exercício 8 ---")
print("Dataframe apenas com máquinas normais:")
print(df_limpo)

# --- Exercício 9: Substituição com np.where ---
df_temp = pd.DataFrame({'temperaturas': [80, 82, 85, 81, 300, 83]})
mediana = df_temp['temperaturas'].median()

# np.where(condicao, valor_se_verdadeiro, valor_se_falso)
# Se for maior que 100 (erro grosseiro), troca pela mediana, senão mantém original
df_temp['temperaturas'] = np.where(df_temp['temperaturas'] > 100, mediana, df_temp['temperaturas'])

print(f"\n--- Exercício 9 ---")
print("Temperaturas corrigidas:")
print(df_temp)

# --- Exercício 10: Groupby e IQR por grupo ---
dados_sensor = {
    'Sensor_ID': ['A', 'A', 'A', 'A', 'B', 'B', 'B', 'B'],
    'Valor_Leitura': [10, 12, 11, 50, 100, 102, 101, 5]
}
df_sensor = pd.DataFrame(dados_sensor)

print(f"\n--- Exercício 10 ---")
# Agrupando por Sensor
grupos = df_sensor.groupby('Sensor_ID')

for nome_sensor, dados_grupo in grupos:
    q1_s = dados_grupo['Valor_Leitura'].quantile(0.25)
    q3_s = dados_grupo['Valor_Leitura'].quantile(0.75)
    iqr_s = q3_s - q1_s
    lim_sup_s = q3_s + 1.5 * iqr_s
    lim_inf_s = q1_s - 1.5 * iqr_s
    
    anomalias = dados_grupo[(dados_grupo['Valor_Leitura'] < lim_inf_s) | 
                            (dados_grupo['Valor_Leitura'] > lim_sup_s)]
    
    print(f"Sensor {nome_sensor} - Limites: [{lim_inf_s}, {lim_sup_s}]")
    print(f"Anomalias encontradas: {anomalias['Valor_Leitura'].values}")