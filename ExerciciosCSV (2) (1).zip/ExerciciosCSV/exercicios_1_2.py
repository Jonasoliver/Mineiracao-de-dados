import numpy as np

# --- Exercício 1 ---
tempos = [12, 15, 14, 13, 16, 12, 14, 150, 13, 15]

# Calculando Q1 (25%), Q2 (50%) e Q3 (75%)
q1 = np.percentile(tempos, 25)
q2 = np.percentile(tempos, 50)
q3 = np.percentile(tempos, 75)

print(f"--- Exercício 1 ---")
print(f"Q1: {q1}")
print(f"Q2 (Mediana): {q2}")
print(f"Q3: {q3}")

# --- Exercício 2 ---
# Calculando o IQR e Limites
iqr = q3 - q1
limite_inferior = q1 - (1.5 * iqr)
limite_superior = q3 + (1.5 * iqr)

print(f"\n--- Exercício 2 ---")
print(f"IQR: {iqr}")
print(f"Limite Inferior: {limite_inferior}")
print(f"Limite Superior: {limite_superior}")
# Observação: O valor 150 será detectado como outlier aqui.