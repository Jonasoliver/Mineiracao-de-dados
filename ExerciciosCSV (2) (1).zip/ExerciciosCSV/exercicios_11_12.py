import pandas as pd

# --- Exercício 11: Carregar, Contar NaN e Preencher ---

# Carregando o CSV
try:
    df = pd.read_csv('dados_sensores.csv')
    print("Arquivo carregado com sucesso!")
except FileNotFoundError:
    print("Erro: O arquivo 'dados_sensores.csv' não foi encontrado.")
    # Criando um dataframe de exemplo caso você rode sem o arquivo
    df = pd.DataFrame() 

if not df.empty:
    # Contar ausentes
    nulos = df.isna().sum()
    print("\n--- Exercício 11: Dados Ausentes ---")
    print(nulos)

    # Preencher com a mediana
    mediana_temp = df['temperatura_celsius'].median()
    mediana_pressao = df['pressao_psi'].median()

    df['temperatura_celsius'] = df['temperatura_celsius'].fillna(mediana_temp)
    df['pressao_psi'] = df['pressao_psi'].fillna(mediana_pressao)

    print("\nValores nulos após tratamento:", df.isna().sum().sum())

    # --- Exercício 12: Remover Outliers e Exportar ---
    
    # Função auxiliar para calcular limites
    def get_limites(series):
        q1 = series.quantile(0.25)
        q3 = series.quantile(0.75)
        iqr = q3 - q1
        return q1 - 1.5 * iqr, q3 + 1.5 * iqr

    # Limites Temperatura
    lim_inf_temp, lim_sup_temp = get_limites(df['temperatura_celsius'])
    
    # Limites Pressão
    lim_inf_pres, lim_sup_pres = get_limites(df['pressao_psi'])

    print(f"\n--- Exercício 12: Limites Calculados ---")
    print(f"Temp: {lim_inf_temp:.2f} a {lim_sup_temp:.2f}")
    print(f"Pressão: {lim_inf_pres:.2f} a {lim_sup_pres:.2f}")

    # Filtrar (Manter apenas o que está DENTRO dos limites em AMBAS as colunas)
    # Note: O exercício pede para remover se contiver outlier em "qualquer uma".
    # Logo, para ficar, a linha tem que ser normal na Temp E normal na Pressão.
    condicao_temp = (df['temperatura_celsius'] >= lim_inf_temp) & (df['temperatura_celsius'] <= lim_sup_temp)
    condicao_pres = (df['pressao_psi'] >= lim_inf_pres) & (df['pressao_psi'] <= lim_sup_pres)

    df_validado = df[condicao_temp & condicao_pres]

    linhas_removidas = len(df) - len(df_validado)
    print(f"\nLinhas removidas (outliers): {linhas_removidas}")
    print(f"Linhas restantes: {len(df_validado)}")

    # Exportar
    df_validado.to_csv('dados_validados.csv', index=False)
    print("Arquivo 'dados_validados.csv' exportado com sucesso!")

else:
    print("Não foi possível prosseguir sem os dados.")