import numpy as np

# --- Exercício 3: Divisão manual de lista par ---
lista = [100, 150, 200, 250, 300, 350]
n = len(lista)
meio = n // 2

# Fatiamento (Slicing)
metade_inferior = lista[:meio]
metade_superior = lista[meio:]

print(f"--- Exercício 3 ---")
print(f"Metade Inferior: {metade_inferior}")
print(f"Metade Superior: {metade_superior}")

# --- Exercício 4: Tensão Elétrica e Filtro Manual ---
tensoes = [110, 115, 120, 118, 112, 220, 116, 114, 119, 12]

# Usando numpy para facilitar o cálculo dos limites
q1_t, q3_t = np.percentile(tensoes, [25, 75])
iqr_t = q3_t - q1_t
lim_inf_t = q1_t - (1.5 * iqr_t)
lim_sup_t = q3_t + (1.5 * iqr_t)

anomalas = []
for t in tensoes:
    if t < lim_inf_t or t > lim_sup_t:
        anomalas.append(t)

print(f"\n--- Exercício 4 ---")
print(f"Limites: {lim_inf_t} a {lim_sup_t}")
print(f"Tensões Anômalas: {anomalas}")

# --- Exercício 5: Função detectar_anomalias ---
def detectar_anomalias(dados, multiplicador=1.5):
    q1 = np.percentile(dados, 25)
    q3 = np.percentile(dados, 75)
    iqr = q3 - q1
    
    lim_inf = q1 - (multiplicador * iqr)
    lim_sup = q3 + (multiplicador * iqr)
    
    outliers = [x for x in dados if x < lim_inf or x > lim_sup]
    return outliers

# --- Exercício 6: Teste da Função ---
vetor_teste = [45, 50, 55, 60, 48, 52, 51, 98, 49, 53]
resultado = detectar_anomalias(vetor_teste)

print(f"\n--- Exercício 6 ---")
print(f"Outliers detectados pela função: {resultado}")