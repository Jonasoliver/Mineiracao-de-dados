import pandas as pd
import numpy as np

dados = {
    "id_paciente": [1, 2, 3, 4, 5, 6, 7],
    "Altura_Metros": [1.72, 1.60, 2.03, 0.40, 2.80, 170, "1.75"],
}

df = pd.DataFrame(dados)

print("DataFrame original:")
print(df)

# Converter para número com segurança
df["Altura_num"] = pd.to_numeric(df["Altura_Metros"], errors="coerce")

min_altura = 0.50
max_altura = 2.50

alturas_impossiveis = df[
    df["Altura_num"].isna()
    | (df["Altura_num"] < min_altura)
    | (df["Altura_num"] > max_altura)
]

print(f"\nRegra: altura deve estar entre {min_altura} e {max_altura} metros.")
print("\nPacientes com alturas suspeitas/impossíveis:")
print(alturas_impossiveis)

print("\nQuantidade isolada:", len(alturas_impossiveis))