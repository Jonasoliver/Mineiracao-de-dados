# Atividade Python

Este projeto contem exercicios (`ex1.py` ate `ex8.py`) que usam bibliotecas externas.

## Requisitos

- Python 3.14 (recomendado) ou 3.13+
- `pip`

Observacao: evite Python `3.15 alpha`, pois algumas bibliotecas podem falhar na instalacao.

## Como rodar (Windows PowerShell)

1. Abra a pasta do projeto no terminal.
2. Crie um ambiente virtual:

```powershell
py -3.14 -m venv .venv
```

3. Ative o ambiente virtual:

```powershell
.\.venv\Scripts\Activate.ps1
```

4. Instale as dependencias:

```powershell
pip install -r requirements.txt
```

5. Rode qualquer exercicio:

```powershell
python ex1.py
python ex2.py
python ex3.py
```

## Envio para o professor

- Compacte a pasta sem incluir `.venv`.
- Inclua estes arquivos no zip:
  - `ex1.py` ate `ex8.py`
  - `requirements.txt`
  - `README.md`

Com isso, quem receber o projeto so precisa seguir os passos acima para executar.
