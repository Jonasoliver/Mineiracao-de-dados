import pandas as pd
import numpy as np
from datetime import datetime

ano_atual = datetime.now().year

dados = {
    "id_aluno": [1, 2, 3, 4, 5, 6],
    "Ano_Nascimento": [2008, 2005, 2010, 2000, 2028, None],
    "Idade_Declarada": [18, 20, 15, 25, 2, 30],
}

df = pd.DataFrame(dados)

print("DataFrame original:")
print(df)

# Converter para numérico com segurança
df["Ano_Nascimento_num"] = pd.to_numeric(df["Ano_Nascimento"], errors="coerce")
df["Idade_Declarada_num"] = pd.to_numeric(df["Idade_Declarada"], errors="coerce")

# Idade real aproximada (sem considerar mês/dia, como o enunciado sugere)
df["Idade_Real"] = ano_atual - df["Ano_Nascimento_num"]

# Contradição:
# - idade real != idade declarada
# - e precisa ter ambos calculáveis
contradicoes = df[
    df["Ano_Nascimento_num"].notna()
    & df["Idade_Declarada_num"].notna()
    & (df["Idade_Real"] != df["Idade_Declarada_num"])
]

print(f"\nAno atual usado no cálculo: {ano_atual}")
print("\nLinhas com contradição (Idade_Real != Idade_Declarada):")
print(contradicoes)

print("\nQuantidade de contradições:", len(contradicoes))