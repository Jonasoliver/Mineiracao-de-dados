import pandas as pd
import numpy as np

# Exemplo de dados (simulando a planilha)
dados = {
    "id_compra": [1001, 1002, 1003, 1004, 1005],
    "Data_Compra": ["2026-02-10", "2026-02-12", "2026-02-15", "2026-02-20", "2026-02-25"],
    "Data_Entrega": ["2026-02-11", "2026-02-10", "2026-02-18", "2026-02-19", None],
}

df = pd.DataFrame(dados)

print("DataFrame original:")
print(df)

# Converter para datetime (erros viram NaT)
df["Data_Compra_dt"] = pd.to_datetime(df["Data_Compra"], errors="coerce")
df["Data_Entrega_dt"] = pd.to_datetime(df["Data_Entrega"], errors="coerce")

# Erro lógico: entrega antes da compra
erros_logicos = df[df["Data_Entrega_dt"].notna() & (df["Data_Entrega_dt"] < df["Data_Compra_dt"])]

print("\nCompras com erro lógico (entrega antes da compra):")
print(erros_logicos)

print("\nQuantidade de erros lógicos:", len(erros_logicos))