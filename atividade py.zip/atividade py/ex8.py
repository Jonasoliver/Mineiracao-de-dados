import pandas as pd
import numpy as np

dados = {
    "componente": ["Resistor 10k", "Capacitor 100nF", "ESP32", "LED 5mm", "Transistor", "Diodo"],
    "Quantidade_Estoque": [1500, -20, 32, 2.5, None, 250000],
}

df = pd.DataFrame(dados)

print("DataFrame original:")
print(df)

# Converter para numérico com segurança
df["qtd_num"] = pd.to_numeric(df["Quantidade_Estoque"], errors="coerce")

# Regras
max_fisico = 100000  # ajuste se seu professor não quiser teto; pode comentar este critério

falhas = df[
    df["qtd_num"].isna()                 # vazio / texto inválido
    | (df["qtd_num"] < 0)                # negativo
    | (df["qtd_num"] % 1 != 0)           # não inteiro
    | (df["qtd_num"] > max_fisico)       # acima do limite físico do armazém (opcional)
]

print("\nComponentes com falha de integridade em Quantidade_Estoque:")
print(falhas)

print("\nQuantidade de registros com falha:", len(falhas))