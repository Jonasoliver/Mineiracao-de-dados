import pandas as pd
import numpy as np

# Exemplo (simulando muitos registros e alguns erros de digitação)
dados = {
    "Sistema_Operacional": (
        ["Ubuntu"] * 520
        + ["Debian"] * 310
        + ["Armbian"] * 140
        + ["Ubunto"] * 8          # erro de digitação
        + ["Ubutnu"] * 4          # erro de digitação
        + ["Debain"] * 6          # erro de digitação
        + ["ArmbianOS"] * 3       # variação rara
        + ["Windows"] * 9         # categoria pequena
    )
}

df = pd.DataFrame(dados)

# Proporção por categoria
proporcoes = df["Sistema_Operacional"].value_counts(normalize=True) * 100  # em %
print("Proporção por categoria (%):")
print(proporcoes)

# Isolar categorias < 5%
raras = proporcoes[proporcoes < 5]
print("\nCategorias raras (< 5%):")
print(raras)

# Se você quiser o DataFrame só com as linhas dessas categorias raras:
df_raras = df[df["Sistema_Operacional"].isin(raras.index)]
print("\nLinhas que pertencem a categorias raras:")
print(df_raras.head(20))
print("\nTotal de linhas raras:", len(df_raras))