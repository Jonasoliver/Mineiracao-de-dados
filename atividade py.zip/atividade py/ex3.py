import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Exemplo de base (simulando um formulário com muitos vazios)
dados = {
    "nome": ["João", "Maria", "Pedro", "Ana", "Lucas", "Bia", "Rafael", "Sofia"],
    "idade": [18, np.nan, 16, np.nan, 18, 20, np.nan, 22],
    "email": ["joao@email.com", None, "pedro@email.com", None, None, "bia@email.com", None, "sofia@email.com"],
    "telefone": [None, "1199999-0000", None, None, "1198888-0000", None, None, "1197777-0000"],
    "cidade": ["SP", "RJ", None, "SP", "MG", None, "BA", "RS"],
}

df = pd.DataFrame(dados)

print("Resumo de nulos por coluna:")
print(df.isnull().sum())

# Mapa de calor: True/False para nulos
plt.figure(figsize=(10, 4))
sns.heatmap(df.isnull(), cbar=False, cmap="viridis")

plt.title("Mapa de calor de valores ausentes (NaN)")
plt.xlabel("Colunas")
plt.ylabel("Linhas")
plt.tight_layout()
plt.show()