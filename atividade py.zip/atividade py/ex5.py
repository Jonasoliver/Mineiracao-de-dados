import pandas as pd
import numpy as np

dados = {
    "id_acesso": [1, 2, 3, 4, 5, 6],
    "Placa_Veiculo": ["ABC1234", "AB-1234", "ABCDE12", "ABC123", " ABC1234", None],
}

df = pd.DataFrame(dados)

print("DataFrame original:")
print(df)

# Garantir que é texto (None vira NaN; vamos tratar como string vazia só para medir)
placa_str = df["Placa_Veiculo"].astype("string")

# Comprimento (strings nulas ficam <NA>; vamos considerar isso como inválido também)
tam = placa_str.str.len()

# Filtrar tamanho incorreto (inclui nulos)
placas_invalidas = df[(tam != 7) | tam.isna()]

print("\nVeículos com placa em tamanho incorreto (≠ 7):")
print(placas_invalidas)

print("\nQuantidade de placas inválidas:", len(placas_invalidas))