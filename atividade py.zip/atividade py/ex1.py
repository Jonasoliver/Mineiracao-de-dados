import pandas as pd
import numpy as np

# Exemplo de dados (simulando o lote que veio "sujo")
dados = {
    "id_leitura": [1, 2, 3, 4, 5, 6, 7],
    "Temperatura_C": ["25.3", "26.1", "falha_sinal", "27", "erro", 28.4, "29.0"],
    "Umidade_pct": [55, 57, 58, 56, 60, 59, 61],
}

df = pd.DataFrame(dados)

print("DataFrame original:")
print(df)

# Guardar a coluna original para comparar depois
temp_original = df["Temperatura_C"]

# Converter de forma segura:
# - tudo que não virar número vira NaN
df["Temperatura_C_num"] = pd.to_numeric(df["Temperatura_C"], errors="coerce")

# Linhas onde falhou: original não é nulo, mas convertido virou NaN
falhas = df[df["Temperatura_C_num"].isna() & temp_original.notna()]

print("\nLinhas onde a conversão falhou (texto -> NaN):")
print(falhas)

print("\nQuantidade de falhas:", len(falhas))